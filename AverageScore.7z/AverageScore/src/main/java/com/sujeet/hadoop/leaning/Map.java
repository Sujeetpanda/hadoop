package com.sujeet.hadoop.leaning;

import java.io.IOException;
import java.util.Arrays;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Map extends Mapper<LongWritable,Text,Text,IntWritable>{
	
	private Text outputKey = new Text();
	private IntWritable outputValue = new IntWritable();
	
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
		String line = value.toString();
		String[] arr = line.split(" ");
		outputKey.set(arr[0]);
		outputValue.set(Integer.parseInt(arr[1]));
		context.write(outputKey, outputValue);
	}

}
