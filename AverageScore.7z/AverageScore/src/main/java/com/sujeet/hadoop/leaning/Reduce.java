package com.sujeet.hadoop.leaning;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Reduce extends Reducer<Text, IntWritable, Text, LongWritable>{

	
	private LongWritable result = new LongWritable();
	private Text name = new Text();
	@Override
	protected void reduce(Text key, Iterable<IntWritable> values,
			Context context)
			throws IOException, InterruptedException {
	
		int sum = 0;
		int count = 0;
		Iterator<IntWritable> valuesIt = values.iterator();
		
		while(valuesIt.hasNext()){
			count++;
			sum = sum + valuesIt.next().get();
		}
		Long avg =  (long) (sum / count);
		result.set(avg);
		name.set(key);
		context.write(key, result);
	}	
}