package com.sujeet.hadoop.leaning;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Reduce extends Reducer<Text, Text, Text, Text> {
	
	private Text outputVal = new Text();
	public void reduce(Text key, Iterable<Text> value, Context context) throws IOException, InterruptedException{
		StringBuffer anagramsList = new StringBuffer();
		//print all anagrams on the same line
		for(Text val: value){
			anagramsList.append(val+" ");
		}
		outputVal.set(new String(anagramsList));
		context.write(key, outputVal);
	}
}
