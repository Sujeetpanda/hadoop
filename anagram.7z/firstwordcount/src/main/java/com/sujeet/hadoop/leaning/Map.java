package com.sujeet.hadoop.leaning;

import java.io.IOException;
import java.util.Arrays;
import java.util.StringTokenizer;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Map extends Mapper<LongWritable,Text,Text,Text>{
	
	private Text outputKey = new Text();
	private Text outputValue = new Text();
	
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
		String line = value.toString();
		StringTokenizer tokenizer = new StringTokenizer(line);
		while(tokenizer.hasMoreTokens()){
			String word = tokenizer.nextToken();
			char[] wordChars = word.toCharArray();
			Arrays.sort(wordChars);
			//use sorted string as intermediate key
			outputKey.set(new String(wordChars));
			//use string itself as intermediate value
			outputValue.set(word);
			context.write(outputKey, outputValue);
		}
	}

}
